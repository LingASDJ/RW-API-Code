# Changelog

## [0.0.2-DEV1.0](https://github.com/LingASDJ/RW-API-Code/compare/v0.0.2-DEV1.0...v0.0.2-DEV1.0) (2023-05-10)


### Bug Fixes

* 重置404 ([1d16b1a](https://github.com/LingASDJ/RW-API-Code/commit/1d16b1acb2c3f61544ac6c41fdf35367b537af55))


### update

* 添加firebase管控 ([560bfc5](https://github.com/LingASDJ/RW-API-Code/commit/560bfc515d55b679b9777d6998de133914a2c1e1))


### Docs

* **contributor:** contrib-readme-action has updated readme ([7d211c1](https://github.com/LingASDJ/RW-API-Code/commit/7d211c19a0ca716675be161e89d6969fb80615c9))

## [0.0.2-DEV1.0](https://github.com/LingASDJ/RW-API-Code/compare/v0.0.2-DEV1.0...v0.0.2-DEV1.0) (2023-05-10)


### Bug Fixes

* 重置404 ([1d16b1a](https://github.com/LingASDJ/RW-API-Code/commit/1d16b1acb2c3f61544ac6c41fdf35367b537af55))


### update

* 添加firebase管控 ([560bfc5](https://github.com/LingASDJ/RW-API-Code/commit/560bfc515d55b679b9777d6998de133914a2c1e1))

## [0.0.2-DEV1.0](https://github.com/LingASDJ/RW-API-Code/compare/v0.0.2-DEV1.0...v0.0.2-DEV1.0) (2023-04-20)


### Bug Fixes

* 重置404 ([1d16b1a](https://github.com/LingASDJ/RW-API-Code/commit/1d16b1acb2c3f61544ac6c41fdf35367b537af55))


### update

* 添加firebase管控 ([560bfc5](https://github.com/LingASDJ/RW-API-Code/commit/560bfc515d55b679b9777d6998de133914a2c1e1))

## [0.0.2-DEV1.0](https://github.com/LingASDJ/RW-API-Code/compare/v1.0.0...v0.0.2-DEV1.0) (2023-04-12)


### 更新

* 0.0.2-DEV1 ([947a19f](https://github.com/LingASDJ/RW-API-Code/commit/947a19f286764f32dd6922abad4f95449ef1f7d0))

## 1.0.0 (2023-04-11)


### Docs

* **contributor:** contrib-readme-action has updated readme ([ebe2b51](https://github.com/LingASDJ/RW-API-Code/commit/ebe2b51f42310fffa14bd629548ab325e47cb5e4))
